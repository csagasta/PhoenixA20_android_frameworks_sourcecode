/*
 *  arch/arm/mach-softwinner/include/mach/uncompress.h
 *
 *  Copyright (C) 2003 ARM Limited
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
//	#define AMBA_UART_DR	(*(volatile unsigned char *)0x101F1000 0x01C21000)
//	#define AMBA_UART_LCRH	(*(volatile unsigned char *)0x101F102C)
//	#define AMBA_UART_CR	(*(volatile unsigned char *)0x101F1030)
//	#define AMBA_UART_FR	(*(volatile unsigned char *)0x101F1018)

//#define AMBA_UART_DR	(*(volatile unsigned char *)0x01C21000)
//#define AMBA_UART_LSR	(*(volatile unsigned char *)0x01C21014)

/*
 * This does not append a newline
 */
static inline void putc(int c)
{
//	while ((AMBA_UART_LSR & 0X20) == 0)
//		barrier();
//	AMBA_UART_DR = c;
//	while ((AMBA_UART_LSR & 0X20) == 0)
//		barrier();
}

static inline void flush(void)
{
//		while (AMBA_UART_FR & (1 << 3))
//			barrier();
}

/*
 * nothing to do
 */
#define arch_decomp_setup()
#define arch_decomp_wdog()
