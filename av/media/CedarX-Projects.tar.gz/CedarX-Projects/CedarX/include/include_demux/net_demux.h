#ifndef __NET_DEMUX_H_
#define __NET_DEMUX_H_


#include <cedarx_demux.h>

extern CedarXDemuxerAPI cdx_dmxs_network;
extern CedarXDemuxerAPI cdx_dmxs_rtsp;

#endif
